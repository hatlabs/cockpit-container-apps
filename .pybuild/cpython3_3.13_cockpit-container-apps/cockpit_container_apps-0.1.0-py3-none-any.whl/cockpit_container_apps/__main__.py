"""Allow running as python -m cockpit_container_apps."""

from cockpit_container_apps.cli import main

if __name__ == "__main__":
    main()
