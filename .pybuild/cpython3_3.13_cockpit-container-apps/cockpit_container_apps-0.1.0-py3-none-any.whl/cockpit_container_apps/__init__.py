"""
Cockpit Container Apps backend.

Container app management backend for Cockpit, providing CLI commands for
browsing, installing, and configuring container applications.
"""

__version__ = "0.1.0"
